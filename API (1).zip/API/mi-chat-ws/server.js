const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');

// ── Servidor HTTP para servir index.html ──
const server = http.createServer((req, res) => {
  if (req.url === '/' || req.url === '/index.html') {
    fs.readFile(path.join(__dirname, 'index.html'), (err, data) => {
      if (err) { res.writeHead(404); res.end('Not found'); return; }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });
  } else {
    res.writeHead(404); res.end();
  }
});

const wss = new WebSocket.Server({ server });

// ── Colores para los usuarios ──
const COLORS = [
  '#00C2A8','#3D7EFF','#FF6B6B','#F7C948','#A78BFA',
  '#34D399','#FB923C','#60A5FA','#F472B6','#4ADE80'
];

// ── Mapa: ws → { id, name, color } ──
const clientes = new Map();
let contador = 0;

function broadcast(data) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) ws.send(msg);
  });
}

function broadcastExcept(data, excluir) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(ws => {
    if (ws !== excluir && ws.readyState === WebSocket.OPEN) ws.send(msg);
  });
}

function listaUsuarios() {
  return Array.from(clientes.values())
    .filter(u => u.name)
    .map(u => ({
    id: u.id, name: u.name, color: u.color
  }));
}

wss.on('connection', (ws) => {
  contador++;
  const id = `u${contador}`;
  const color = COLORS[(contador - 1) % COLORS.length];
  clientes.set(ws, { id, name: null, color });

  console.log(`[+] Conexión nueva: ${id}. Total: ${clientes.size}`);

  // Enviar bienvenida con ID y color asignado
  ws.send(JSON.stringify({ type: 'welcome', id, color }));

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    const user = clientes.get(ws);
    if (!user) return;

    switch (msg.type) {

      case 'join': {
        const name = (msg.name || '').trim().slice(0, 30) || `Usuario${contador}`;
        user.name = name;

        // Enviar lista actual al recién llegado
        ws.send(JSON.stringify({ type: 'userList', users: listaUsuarios() }));

        // Notificar a los demás que alguien llegó
        broadcastExcept({ type: 'userJoined', id, name, color }, ws);

        // Mensaje de sistema para todos
        broadcast({ type: 'system', text: `${name} se unió al chat` });

        console.log(`[JOIN] ${name} (${id})`);
        break;
      }

      case 'message': {
        if (!user.name) return;
        const text = (msg.text || '').trim().slice(0, 500);
        if (!text) return;

        // Difundir a TODOS (incluido el que envió)
        broadcast({
          type: 'message',
          id: user.id,
          name: user.name,
          color: user.color,
          text,
          ts: Date.now()
        });

        console.log(`[MSG] ${user.name}: ${text}`);
        break;
      }

      case 'typing': {
        if (!user.name) return;
        broadcastExcept({
          type: 'typing',
          id: user.id,
          name: user.name,
          color: user.color,
          active: !!msg.active
        }, ws);
        break;
      }
    }
  });

  ws.on('close', () => {
    const user = clientes.get(ws);
    clientes.delete(ws);
    if (user && user.name) {
      console.log(`[-] ${user.name} desconectado. Total: ${clientes.size}`);
      broadcast({ type: 'userLeft', id: user.id, name: user.name });
      broadcast({ type: 'system', text: `${user.name} salió del chat` });
    }
  });

  ws.on('error', () => clientes.delete(ws));
});

const PORT = 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n╔══════════════════════════════════════════════╗`);
  console.log(`║        🚀  NexusChat arrancado               ║`);
  console.log(`╠══════════════════════════════════════════════╣`);
  console.log(`║  Tú  →  http://localhost:3000                ║`);
  console.log(`║  LAN →  http://192.168.1.17:3000             ║`);
  console.log(`╠══════════════════════════════════════════════╣`);
  console.log(`║  Comparte la URL de LAN con los demás        ║`);
  console.log(`║  (deben estar en la misma red Wi-Fi)         ║`);
  console.log(`╚══════════════════════════════════════════════╝\n`);
});
