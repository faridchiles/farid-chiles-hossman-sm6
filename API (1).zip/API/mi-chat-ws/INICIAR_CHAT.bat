@echo off
title NexusChat - Diagnostico
color 0A

echo.
echo  ==========================================
echo    NexusChat - Verificando todo...
echo  ==========================================
echo.

:: Verificar administrador
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo  [ERROR] No estas ejecutando como ADMINISTRADOR
    echo.
    echo  Solucion: Clic derecho en este archivo
    echo            y elige "Ejecutar como administrador"
    echo.
    pause
    exit /b 1
)
echo  [OK] Ejecutando como administrador

:: Verificar Node.js
echo.
echo  Verificando Node.js...
where node >nul 2>&1
if %errorLevel% neq 0 (
    echo  [ERROR] Node.js NO esta instalado
    echo.
    echo  Solucion:
    echo  1. Ve a https://nodejs.org
    echo  2. Descarga la version LTS ^(boton verde grande^)
    echo  3. Instalalo con todas las opciones por defecto
    echo  4. Reinicia la PC
    echo  5. Vuelve a ejecutar este archivo
    echo.
    pause
    exit /b 1
)
for /f %%i in ('node --version') do echo  [OK] Node.js %%i instalado

:: Verificar archivos
echo.
echo  Verificando archivos...
if not exist "%~dp0server.js" (
    echo  [ERROR] No se encuentra server.js
    echo  Asegurate de que todos los archivos esten en la misma carpeta
    echo.
    pause
    exit /b 1
)
echo  [OK] server.js encontrado

if not exist "%~dp0index.html" (
    echo  [ERROR] No se encuentra index.html
    echo.
    pause
    exit /b 1
)
echo  [OK] index.html encontrado

:: Instalar dependencias
echo.
echo  Instalando dependencias...
cd /d "%~dp0"
if not exist "node_modules\ws" (
    call npm install
    if %errorLevel% neq 0 (
        echo  [ERROR] Fallo npm install
        pause
        exit /b 1
    )
)
echo  [OK] Dependencias listas

:: Abrir puerto firewall
echo.
echo  Abriendo puerto 3000 en Firewall...
netsh advfirewall firewall delete rule name="NexusChat-3000" >nul 2>&1
netsh advfirewall firewall add rule name="NexusChat-3000" dir=in action=allow protocol=TCP localport=3000 >nul 2>&1
echo  [OK] Puerto 3000 abierto

:: Mostrar IPs
echo.
echo  ==========================================
echo   TU abre:      http://localhost:3000
echo   OTROS abren:  http://192.168.1.17:3000
echo  ==========================================
echo.
echo  Iniciando servidor... (no cierres esta ventana)
echo.

cd /d "%~dp0"
node server.js

echo.
echo  [!] El servidor se detuvo.
pause
